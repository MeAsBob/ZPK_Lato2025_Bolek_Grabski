﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using TodoAppv2.Components;

namespace TodoAppv2.Pages
{
    public class IndexModel : PageModel
    {
        public TodoListComponent Lista { get; set; }
        public StatsComponent Statystyki { get; set; }

        public void OnGet()
        {
            var zadanie = new TodoItemComponent
            {
                Id = 1,
                Title = "Testowe zadanie",
                Description = "Z widoku webowego",
                IsCompleted = true
            };

            Lista = new TodoListComponent();
            Lista.Add(zadanie);

            Statystyki = new StatsComponent();
            Statystyki.Generate(Lista);
        }
    }
}
